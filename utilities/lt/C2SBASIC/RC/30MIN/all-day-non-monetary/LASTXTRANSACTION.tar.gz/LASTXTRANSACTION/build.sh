podman build -t default-route-openshift-image-registry.apps.pocpbm-nexp.grameenphone.com/openshift/gp_exlastxtrfreq_lt:v1  .
