kubectl delete configmap cs3simulator-config   --namespace ers-prod
