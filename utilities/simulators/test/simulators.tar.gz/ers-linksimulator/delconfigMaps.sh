kubectl delete configmap linksimulator-config   --namespace ers-prod
